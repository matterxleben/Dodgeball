# Assignment 2
When you see this in GitHub, you've successfully pushed a version of your code there. Please remember to push your code again (in the terminal, type `git push`) right before you mark the assignment as completed.

Open Codio and use **Tools > Guide > Play** to see assignment instructions.

## Creating Java programs in Codio

### Make a new file
Use **File > New File...** or right-click in the file tree to create a new file. You can right-click in the file tree to rename or delete files.

As Codio detects which file is in focus, simply put your cursor into whichever code editor you want to compile and run.

### Reconfigure your Panels for easier development
Use the **View > Panels** menu on the top tool bar to segment your screen.

Simply drag the tab of the file or terminal (the part with the name) you want to move into the new panel.
# a2-matterxleben
